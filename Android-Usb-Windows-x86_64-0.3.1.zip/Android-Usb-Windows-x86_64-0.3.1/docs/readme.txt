Note that dragging and dropping files will not work on Android, due to some file IO issues.
I am guessing it would not have worked anyway, as I don't see how you would drag and drop.

The included copy of adb is version 1.0.31.
You can use your own adb by changing the 'cl_adb_path' option.
Just hit the tilde/grave key to open a console, type 'cl_adb_path /path/to/adb' (without the quotes), and hit enter.
